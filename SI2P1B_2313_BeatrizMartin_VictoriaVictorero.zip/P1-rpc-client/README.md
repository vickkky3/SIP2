# si2_alumnos
codigo necesario en las prácticas de si2
